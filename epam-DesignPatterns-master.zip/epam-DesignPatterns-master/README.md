# epam-DesignPatterns
epam hometask 7 - Design Patterns
