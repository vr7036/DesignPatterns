package com.epam.abstractFactory;

public interface Animals {
	public void eats();
	public void makeSound();
	public void sleeps();
}
