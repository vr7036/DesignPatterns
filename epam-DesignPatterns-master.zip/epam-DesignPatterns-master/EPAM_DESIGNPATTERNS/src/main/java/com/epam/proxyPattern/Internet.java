package com.epam.proxyPattern;

public interface Internet {
	public void connectTo(String message) throws Exception;
}
